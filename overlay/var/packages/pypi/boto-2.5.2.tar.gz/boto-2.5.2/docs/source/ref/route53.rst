.. ref-route53

=======
route53
=======


boto.route53.connection
-----------------------

.. automodule:: boto.route53.connection
   :members:   
   :undoc-members:

boto.route53.hostedzone
------------------------

.. automodule:: boto.route53.hostedzone
   :members:   
   :undoc-members:

boto.route53.record
-------------------

.. automodule:: boto.route53.record
   :members:   
   :undoc-members:

boto.route53.exception
----------------------

.. automodule:: boto.route53.exception
   :members:   
   :undoc-members:
