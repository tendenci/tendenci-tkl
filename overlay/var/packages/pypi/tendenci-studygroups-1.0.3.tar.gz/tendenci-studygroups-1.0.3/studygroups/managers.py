from tendenci.core.perms.managers import TendenciBaseManager

class StudyGroupManager(TendenciBaseManager):
    """
    Model Manager
    """
    pass
    
    
class PositionManager(TendenciBaseManager):
    """
    Model Manager
    """
    pass
