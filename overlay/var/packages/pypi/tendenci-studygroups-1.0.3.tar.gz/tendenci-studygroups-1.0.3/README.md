tendenci-studygroups
====================

Studygroups addon for Tendenci.