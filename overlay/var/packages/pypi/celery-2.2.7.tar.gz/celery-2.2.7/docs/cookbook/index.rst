.. _cookbook:

===========
 Cookbook
===========

.. toctree::
    :maxdepth: 2

    tasks
    daemonizing

This page contains common recipes and techniques.
