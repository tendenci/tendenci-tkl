
from example.settings import *
DEBUG=True
TEMPLATE_DEBUG=DEBUG
