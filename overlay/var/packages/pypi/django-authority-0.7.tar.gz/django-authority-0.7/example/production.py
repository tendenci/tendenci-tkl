
from example.settings import *
