from photologue.tests.effect import *
from photologue.tests.gallery import *
from photologue.tests.photo import *
from photologue.tests.resize import *
from photologue.tests.views_photo import *
from photologue.tests.views_gallery import *
from photologue.tests.sitemap import *
