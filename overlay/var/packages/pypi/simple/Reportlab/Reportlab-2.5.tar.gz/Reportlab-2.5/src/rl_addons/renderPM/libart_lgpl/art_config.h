#ifndef _ART_CONFIG_H
#	define _ART_CONFIG_H
#	define ART_SIZEOF_CHAR 1
#	define ART_SIZEOF_SHORT 2
#	define ART_SIZEOF_INT 4
#	define ART_SIZEOF_LONG 4
typedef unsigned char art_u8;
typedef unsigned short art_u16;
typedef unsigned int art_u32;
#endif
