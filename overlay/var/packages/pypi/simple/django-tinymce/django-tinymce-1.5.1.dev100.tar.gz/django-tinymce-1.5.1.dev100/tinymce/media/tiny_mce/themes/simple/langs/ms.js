tinyMCE.addI18n('ms.simple',{
bold_desc:"Tebal (Ctrl+B)",
italic_desc:"Condong (Ctrl+I)",
underline_desc:"Garis bawah (Ctrl+U)",
striketrough_desc:"Garis tengah",
bullist_desc:"Senarai tidak tertib",
numlist_desc:"Senarai tertib",
undo_desc:"Buat asal (Ctrl+Z)",
redo_desc:"Buat semula (Ctrl+Y)",
cleanup_desc:"Bersihkan kod yang bersepah"
});