tinyMCE.addI18n('sk.simple',{
bold_desc:"Tu\u010Dn\u00E9 (Ctrl+B)",
italic_desc:"Kurz\u00EDva (Ctrl+I)",
underline_desc:"Pod\u010Diarknut\u00E9 (Ctrl+U)",
striketrough_desc:"Pre\u010Diarknut\u00E9",
bullist_desc:"Zoznam s odr\u00E1\u017Ekami",
numlist_desc:"\u010C\u00EDslovan\u00FD zoznam",
undo_desc:"Sp\u00E4\u0165 (Ctrl+Z)",
redo_desc:"Znovu (Ctrl+Y)",
cleanup_desc:"Vy\u010Disti\u0165 k\u00F3d"
});