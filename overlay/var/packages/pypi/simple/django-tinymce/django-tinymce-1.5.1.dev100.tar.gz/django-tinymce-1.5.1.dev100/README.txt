This Django application provides a TinyMCE widget.

Copyright (C) 2008 Joost Cassee
This program is licensed under the MIT License (see LICENSE.txt)

See http://django-tinymce.googlecode.com for docs.

-- 
Joost Cassee
joost@cassee.net
