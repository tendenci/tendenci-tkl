tinyMCE.addI18n('et.simple',{
bold_desc:"Rasvane (Ctrl+B)",
italic_desc:"Kursiiv (Ctrl+I)",
underline_desc:"Allajoonitud (Ctrl+U)",
striketrough_desc:"L\u00E4bijoonitud",
bullist_desc:"Ebakorrap\u00E4rane loetelu",
numlist_desc:"Korrap\u00E4rane loetelu",
undo_desc:"V\u00F5ta tagasi (Ctrl+Z)",
redo_desc:"Tee uuesti (Ctrl+Y)",
cleanup_desc:"Puhasta segane kood"
});