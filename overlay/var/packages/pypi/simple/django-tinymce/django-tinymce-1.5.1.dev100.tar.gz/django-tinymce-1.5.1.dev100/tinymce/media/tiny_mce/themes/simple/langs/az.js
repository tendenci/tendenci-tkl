tinyMCE.addI18n('az.simple',{
bold_desc:"Yar\u0131qal\u0131n (Ctrl+B)",
italic_desc:"Kursiv (Ctrl+I)",
underline_desc:"Altdan x\u0259tt (Ctrl+U)",
striketrough_desc:"Qaralanm\u0131\u015F",
bullist_desc:"Qeyd edilmi\u015F siyah\u0131",
numlist_desc:"N\u00F6mr\u0259l\u0259nmi\u015F siyah\u0131",
undo_desc:"L\u0259\u011Fv et (Ctrl+Z)",
redo_desc:"T\u0259krarla (Ctrl+Y)",
cleanup_desc:"\u018Fyri kodu t\u0259mizl\u0259"
});