tinyMCE.addI18n('gl.simple',{
bold_desc:"Negri\u00F1a (Ctrl+B)",
italic_desc:"Cursiva (Ctrl+I)",
underline_desc:"Suli\u00F1ado (Ctrl+U)",
striketrough_desc:"Tachado",
bullist_desc:"Lista desordenada",
numlist_desc:"Lista ordenada",
undo_desc:"Desfacer (Ctrl+Z)",
redo_desc:"Re-facer (Ctrl+Y)",
cleanup_desc:"Limpar lixo no c\u00F3digo"
});