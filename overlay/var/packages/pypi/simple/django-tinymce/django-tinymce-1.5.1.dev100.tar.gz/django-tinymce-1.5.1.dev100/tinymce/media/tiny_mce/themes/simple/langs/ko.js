tinyMCE.addI18n('ko.simple',{
bold_desc:"\uAD75\uC740 \uAE00\uC528(Ctrl+B)",
italic_desc:"\uC774\uD0E4\uB9AD(Ctrl+I)",
underline_desc:"\uBC11\uC904(Ctrl+U)",
striketrough_desc:"\uCDE8\uC18C\uC120",
bullist_desc:"\uBE44\uC21C\uCC28\uBAA9\uB85D",
numlist_desc:"\uC21C\uCC28\uBAA9\uB85D",
undo_desc:"\uC2E4\uD589\uCDE8\uC18C(Ctrl+Z)",
redo_desc:"\uB2E4\uC2DC\uC2E4\uD589(Ctrl+Y)",
cleanup_desc:"\uC9C0\uC800\uBD84\uD55C \uCF54\uB4DC \uC0AD\uC81C"
});