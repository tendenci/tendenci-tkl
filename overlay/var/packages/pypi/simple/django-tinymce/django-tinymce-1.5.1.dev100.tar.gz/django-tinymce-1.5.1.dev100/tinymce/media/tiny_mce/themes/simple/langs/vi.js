tinyMCE.addI18n('vi.simple',{
bold_desc:"Ch\u1EEF \u0111\u1EADm (Ctrl+B)",
italic_desc:"Ch\u1EEF nghi\u00EAng (Ctrl+I)",
underline_desc:"G\u1EA1ch ch\u00E2n (Ctrl+U)",
striketrough_desc:"G\u1EA1ch ngang",
bullist_desc:"Danh s\u00E1ch kh\u00F4ng theo th\u1EE9 t\u1EF1",
numlist_desc:"Danh s\u00E1ch theo th\u1EE9 t\u1EF1",
undo_desc:"Tr\u1EDF v\u1EC1 (Ctrl+Z)",
redo_desc:"Ti\u1EBFn t\u1EDBi (Ctrl+Y)",
cleanup_desc:"D\u1ECDn d\u1EB9p m\u00E3 l\u1ED9n x\u1ED9n"
});