tinyMCE.addI18n('fi.simple',{
bold_desc:"Lihavointi (Ctrl+B)",
italic_desc:"Kursivointi (Ctrl+I)",
underline_desc:"Alleviivaus (Ctrl+U)",
striketrough_desc:"Yliviivaus",
bullist_desc:"J\u00E4rjest\u00E4m\u00E4t\u00F6n lista",
numlist_desc:"J\u00E4rjestetty lista",
undo_desc:"Peru (Ctrl+Z)",
redo_desc:"Tee uudestaan (Ctrl+Y)",
cleanup_desc:"Siisti sekainen koodi"
});