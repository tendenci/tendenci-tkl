tinyMCE.addI18n('ca.simple',{
bold_desc:"Negreta (Ctrl+B)",
italic_desc:"Cursiva (Ctrl+I)",
underline_desc:"Subratllat (Ctrl+U)",
striketrough_desc:"Barrat",
bullist_desc:"Llista sense numeraci\u00F3",
numlist_desc:"Llista numerada",
undo_desc:"Desf\u00E9s (Ctrl+Z)",
redo_desc:"Ref\u00E9s (Ctrl+Y)",
cleanup_desc:"Poleix el codi"
});