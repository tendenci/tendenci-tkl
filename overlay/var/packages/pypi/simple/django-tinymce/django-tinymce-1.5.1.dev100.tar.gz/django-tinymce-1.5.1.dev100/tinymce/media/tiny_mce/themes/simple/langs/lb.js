tinyMCE.addI18n('lb.simple',{
bold_desc:"Fett (Strg+B)",
italic_desc:"Kursiv (Strg+I)",
underline_desc:"\u00CBnnerstrach (Strg+U)",
striketrough_desc:"Duerchgestrach",
bullist_desc:"Onsort\u00E9iert L\u00EBscht",
numlist_desc:"Sort\u00E9iert L\u00EBscht",
undo_desc:"R\u00E9ckg\u00E4ngeg (Strg+Z)",
redo_desc:"Widderhuelen (Strg+Y)",
cleanup_desc:"Quellcode botzen"
});