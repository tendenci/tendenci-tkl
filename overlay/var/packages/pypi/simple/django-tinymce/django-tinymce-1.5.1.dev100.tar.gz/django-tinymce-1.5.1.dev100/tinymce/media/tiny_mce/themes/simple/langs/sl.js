tinyMCE.addI18n('sl.simple',{
bold_desc:"Krepko (Ctrl+B)",
italic_desc:"Po\u0161evno (Ctrl+I)",
underline_desc:"Pod\u010Drtano (Ctrl+U)",
striketrough_desc:"Pre\u010Drtano",
bullist_desc:"Alineje",
numlist_desc:"Na\u0161tevanje",
undo_desc:"Razveljavi (Ctrl+Z)",
redo_desc:"Uveljavi (Ctrl+Y)",
cleanup_desc:"Pre\u010Disti kodo"
});