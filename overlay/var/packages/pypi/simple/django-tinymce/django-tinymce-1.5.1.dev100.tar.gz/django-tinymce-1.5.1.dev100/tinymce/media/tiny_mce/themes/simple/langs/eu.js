tinyMCE.addI18n('eu.simple',{
bold_desc:"Beltza (Ctrl+B)",
italic_desc:"Etzana (Ctrl+I)",
underline_desc:"Azpimarratua (Ctrl+U)",
striketrough_desc:"Gainetik marra duena",
bullist_desc:"Zerrenda",
numlist_desc:"Zerrenda ordenatua",
undo_desc:"Desegin (Ctrl+Z)",
redo_desc:"Berregin (Ctrl+Y)",
cleanup_desc:"Kode zikina garbitu"
});