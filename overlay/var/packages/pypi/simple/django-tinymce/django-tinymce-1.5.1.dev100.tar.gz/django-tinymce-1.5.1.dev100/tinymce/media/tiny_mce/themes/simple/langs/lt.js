tinyMCE.addI18n('lt.simple',{
bold_desc:"Pusjuodis (Ctrl+B)",
italic_desc:"Kursyvas (Ctrl+I)",
underline_desc:"Pabrauktas (Ctrl+U)",
striketrough_desc:"Perbrauktas",
bullist_desc:"Nesunumeruotas s\u0105ra\u0161as",
numlist_desc:"Sunumeruotas s\u0105ra\u0161as",
undo_desc:"At\u0161aukti (Ctrl+Z)",
redo_desc:"Gr\u0105\u017Einti (Ctrl+Y)",
cleanup_desc:"I\u0161valyti netvarking\u0105 kod\u0105"
});