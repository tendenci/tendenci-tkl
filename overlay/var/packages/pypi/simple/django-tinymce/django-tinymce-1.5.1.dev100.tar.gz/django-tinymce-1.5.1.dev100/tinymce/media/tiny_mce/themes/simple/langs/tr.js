tinyMCE.addI18n('tr.simple',{
bold_desc:"Kal\u0131n (Ctrl+B)",
italic_desc:"\u0130talik (Ctrl+I)",
underline_desc:"Alt\u0131 \u00E7izili (Ctrl+U)",
striketrough_desc:"\u00DCst\u00FC \u00E7izili",
bullist_desc:"S\u0131ras\u0131z liste",
numlist_desc:"S\u0131ral\u0131 liste",
undo_desc:"Geri al (Ctrl+Z)",
redo_desc:"Yinele (Ctrl+Y)",
cleanup_desc:"Da\u011F\u0131n\u0131k kodu temizle"
});