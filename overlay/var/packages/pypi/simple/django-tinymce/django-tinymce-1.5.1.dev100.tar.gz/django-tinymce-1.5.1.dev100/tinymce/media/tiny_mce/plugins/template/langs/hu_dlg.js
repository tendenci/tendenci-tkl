tinyMCE.addI18n('hu.template_dlg',{
title:"Sablon beilleszt\u00E9se",
label:"Sablon",
desc_label:"Le\u00EDr\u00E1s",
desc:"Sablon beilleszt\u00E9se",
select:"Sablon v\u00E1laszt\u00E1sa",
preview:"El\u0151n\u00E9zet",
warning:"Figyelem: Egy m\u00E1r alkalmazott sablon friss\u00EDt\u00E9se m\u00E1sikkal adatveszt\u00E9ssel j\u00E1rhat.",
mdate_format:"%Y.%m.%d. %H:%M:%S",
cdate_format:"%Y.%m.%d. %H:%M:%S",
months_long:"janu\u00E1r,febru\u00E1r,m\u00E1rcius,\u00E1prilis,m\u00E1jus,j\u00FAnius,j\u00FAlius,augusztus,szeptember,okt\u00F3ber,november,december",
months_short:"jan,feb,m\u00E1r,\u00E1pr,m\u00E1j,j\u00FAn,j\u00FAl,aug,szep,okt,nov,dec",
day_long:"vas\u00E1rnap,h\u00E9tf\u0151,kedd,szerda,cs\u00FCt\u00F6rt\u00F6k,p\u00E9ntek,szombat,vas\u00E1rnap",
day_short:"V,H,K,Sze,Cs,P,Szo,V"
});