tinyMCE.addI18n('zh.simple',{
bold_desc:"\u7C97\u4F53 (Ctrl+B)",
italic_desc:"\u659C\u4F53 (Ctrl+I)",
underline_desc:"\u4E0B\u5212\u7EBF(Ctrl+U)",
striketrough_desc:"\u5220\u9664\u7EBF",
bullist_desc:"\u7B26\u53F7\u5217\u8868",
numlist_desc:"\u7F16\u53F7\u5217\u8868",
undo_desc:"\u8FD8\u539F (Ctrl+Z)",
redo_desc:"\u91CD\u505A (Ctrl+Y)",
cleanup_desc:"\u6E05\u9664\u591A\u4F59\u539F\u59CB\u7801"
});