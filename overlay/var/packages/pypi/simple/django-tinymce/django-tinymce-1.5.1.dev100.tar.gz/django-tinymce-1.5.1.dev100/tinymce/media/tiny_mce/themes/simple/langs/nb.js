tinyMCE.addI18n('nb.simple',{
bold_desc:"Fet",
italic_desc:"Kursiv",
underline_desc:"Understreking",
striketrough_desc:"Gjennomstreking",
bullist_desc:"Punktliste",
numlist_desc:"Nummerliste",
undo_desc:"Angre (Ctrl+Z)",
redo_desc:"Gj\u00F8r om (Ctrl + Y)",
cleanup_desc:"Rens ukurant kode"
});