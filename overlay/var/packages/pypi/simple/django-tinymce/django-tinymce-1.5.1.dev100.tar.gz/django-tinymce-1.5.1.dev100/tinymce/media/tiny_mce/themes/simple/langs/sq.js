tinyMCE.addI18n('sq.simple',{
bold_desc:"I Trash\u00EB (Ctrl+B)",
italic_desc:"I Pjerr\u00EBt (Ctrl+I)",
underline_desc:"I N\u00EBnvizuar (Ctrl+U)",
striketrough_desc:"Vij\u00EB n\u00EB mes",
bullist_desc:"List\u00EB e parregullt",
numlist_desc:"List\u00EB e rregullt",
undo_desc:"\u00C7b\u00EBj (Ctrl+Z)",
redo_desc:"Rib\u00EBj (Ctrl+Y)",
cleanup_desc:"Pastro kodin"
});