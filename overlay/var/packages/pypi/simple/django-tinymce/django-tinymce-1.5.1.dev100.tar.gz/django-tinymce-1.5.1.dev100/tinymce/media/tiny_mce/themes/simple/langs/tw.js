tinyMCE.addI18n('tw.simple',{
bold_desc:"\u7C97\u9AD4 (Ctrl+B)",
italic_desc:"\u659C\u9AD4 (Ctrl+I)",
underline_desc:"\u4E0B\u5283\u7DDA(Ctrl+U)",
striketrough_desc:"\u522A\u9664\u7DDA",
bullist_desc:"\u7B26\u865F\u5217\u8868",
numlist_desc:"\u7DE8\u865F\u5217\u8868",
undo_desc:"\u9084\u539F (Ctrl+Z)",
redo_desc:"\u91CD\u505A (Ctrl+Y)",
cleanup_desc:"\u6E05\u9664\u591A\u9918\u4EE3\u78BC"
});