tinyMCE.addI18n('nl.simple',{
bold_desc:"Vet (Ctrl+B)",
italic_desc:"Cursief (Ctrl+I)",
underline_desc:"Onderstrepen (Ctrl+U)",
striketrough_desc:"Doorhalen",
bullist_desc:"Opsommingstekens",
numlist_desc:"Nummering",
undo_desc:"Ongedaan maken (Ctrl+Z)",
redo_desc:"Herhalen (Ctrl+Y)",
cleanup_desc:"Code opruimen"
});