tinyMCE.addI18n('ro.simple',{
bold_desc:"\u00CEngro\u015Fat (Ctrl+B)",
italic_desc:"Italic (Ctrl+I)",
underline_desc:"Subliniat (Ctrl+U)",
striketrough_desc:"T\u0103iat",
bullist_desc:"List\u0103 neordonat\u0103",
numlist_desc:"List\u0103 ordonat\u0103",
undo_desc:"Undo (Ctrl+Z)",
redo_desc:"Ref\u0103 (Ctrl+Y)",
cleanup_desc:"Cur\u0103\u0163\u0103 cod invalid"
});