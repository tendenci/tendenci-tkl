tinyMCE.addI18n('ia.simple',{
bold_desc:"\u7C97\u4F53(Ctrl+B)",
italic_desc:"\u659C\u4F53(Ctrl+I)",
underline_desc:"\u5E95\u7EBF (Ctrl+U)",
striketrough_desc:"\u4E2D\u5212\u7EBF",
bullist_desc:"\u6E05\u5355\u7B26\u53F7",
numlist_desc:"\u7F16\u53F7",
undo_desc:"\u64A4\u9500 (Ctrl+Z)",
redo_desc:"\u6062\u590D (Ctrl+Y)",
cleanup_desc:"\u5220\u9664\u5197\u4F59\u7801"
});