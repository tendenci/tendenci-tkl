name = 'tinymce'
authors = 'Joost Cassee'
version = '1.5.1.dev100'
release = version
