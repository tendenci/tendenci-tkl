INSERT INTO payments_paymentmethod 
(human_name, machine_name, is_online, admin_only)
VALUES ('Credit Card', 'credit-card', TRUE, FALSE);

INSERT INTO payments_paymentmethod 
(human_name, machine_name, is_online, admin_only)
VALUES ('Check', 'check', FALSE, FALSE);

INSERT INTO payments_paymentmethod 
(human_name, machine_name, is_online, admin_only)
VALUES ('Cash', 'cash', FALSE, FALSE);
