# Dict of event logs that do not belong to an app
