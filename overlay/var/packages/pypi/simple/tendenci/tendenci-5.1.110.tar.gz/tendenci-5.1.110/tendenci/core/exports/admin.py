from django.contrib import admin
from tendenci.core.exports.models import Export

admin.site.register(Export)
