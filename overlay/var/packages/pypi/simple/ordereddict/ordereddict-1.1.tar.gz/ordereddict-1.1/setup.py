# -*- coding: utf-8 -*-
# setup.py
from distutils.core import setup

setup(
    name="ordereddict",
    version="1.1",
    py_modules=['ordereddict']
)
