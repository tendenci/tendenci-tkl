from tendenci.core.perms.managers import TendenciBaseManager

class CommitteeManager(TendenciBaseManager):
    """
    Model Manager
    """
    pass
    
    
class PositionManager(TendenciBaseManager):
    """
    Model Manager
    """
    pass
