tendenci-committees
===================

Committees addon for Tendenci.