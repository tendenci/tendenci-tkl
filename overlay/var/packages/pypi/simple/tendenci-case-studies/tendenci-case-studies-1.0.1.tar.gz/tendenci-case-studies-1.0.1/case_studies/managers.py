from tendenci.core.perms.managers import TendenciBaseManager

class CaseStudyManager(TendenciBaseManager):
    """
    Model Manager
    """
    pass