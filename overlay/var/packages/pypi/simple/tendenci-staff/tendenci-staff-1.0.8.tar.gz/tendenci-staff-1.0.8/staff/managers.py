from tendenci.core.perms.managers import TendenciBaseManager

class StaffManager(TendenciBaseManager):
    """
    Model Manager
    """
    pass