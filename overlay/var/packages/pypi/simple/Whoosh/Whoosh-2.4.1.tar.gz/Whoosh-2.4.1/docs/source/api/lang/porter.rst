======================
``lang.porter`` module
======================

.. automodule:: whoosh.lang.porter

.. autofunction:: stem
