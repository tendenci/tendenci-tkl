=====================================================
 Contrib: Test Runner - djcelery.contrib.test_runner
=====================================================

.. contents::
    :local:
.. currentmodule:: djcelery.contrib.test_runner

.. automodule:: djcelery.contrib.test_runner
    :members:
    :undoc-members:
