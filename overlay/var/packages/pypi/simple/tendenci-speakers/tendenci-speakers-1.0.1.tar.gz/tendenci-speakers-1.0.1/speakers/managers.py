from tendenci.core.perms.managers import TendenciBaseManager

class SpeakerManager(TendenciBaseManager):
    """
    Model Manager
    """
    pass