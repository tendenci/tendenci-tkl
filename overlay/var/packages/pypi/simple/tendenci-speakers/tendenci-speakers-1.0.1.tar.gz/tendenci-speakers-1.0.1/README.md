tendenci-speakers
=================

Speakers addon for Tendenci.