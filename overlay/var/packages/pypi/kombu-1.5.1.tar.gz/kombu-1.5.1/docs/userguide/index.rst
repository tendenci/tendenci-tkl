============
 User Guide
============

:Release: |version|
:Date: |today|

.. toctree::
    :maxdepth: 2

    connections
    producers
    consumers
    examples
    simple
    pools
    serialization
