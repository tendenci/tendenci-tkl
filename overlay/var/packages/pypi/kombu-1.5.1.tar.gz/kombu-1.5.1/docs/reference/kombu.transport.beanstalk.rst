.. currentmodule:: kombu.transport.beanstalk

.. automodule:: kombu.transport.beanstalk

    .. contents::
        :local:

    Transport
    ---------

    .. autoclass:: Transport
        :members:
        :undoc-members:

    Channel
    -------

    .. autoclass:: Channel
        :members:
        :undoc-members:
