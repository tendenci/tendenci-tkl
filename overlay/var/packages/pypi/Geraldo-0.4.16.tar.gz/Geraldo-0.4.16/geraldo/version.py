VERSION = (0, 4, 16)

def get_version():
    return '%d.%d.%d'%VERSION

