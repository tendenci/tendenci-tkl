import non_existent

def erroneous_view(request):
    pass
