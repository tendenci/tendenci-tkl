"""
__init__.py for django-form-utils - templatetags

Time-stamp: <2008-10-13 12:14:37 carljm __init__.py>

"""
